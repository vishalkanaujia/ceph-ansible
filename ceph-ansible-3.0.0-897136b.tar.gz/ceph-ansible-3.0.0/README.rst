ceph-ansible
============
Ansible playbooks for Ceph, the distributed filesystem.

Please refer to our hosted documentation here: http://docs.ceph.com/ceph-ansible/master/

You can view documentation for our ``stable-*`` branches by substituting ``master`` in the link
above for the name of the branch. For example: http://docs.ceph.com/ceph-ansible/stable-2.2/ 
